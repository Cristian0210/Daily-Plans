//
//  TaskRow.swift
//  Planes
//
//  Created by Cristian Vangheli on 24/2/23.
//

import SwiftUI

//MARK: - En este apartado he creado el circulo para saber cual tarea esta echa y cual no.

struct TaskRow: View {
    var task: String
    var completed: Bool
    
    var body: some View {
        HStack (spacing: 20){
            Image(systemName: completed ? "checkmark.circle" : "circle")
            
            Text(task)
        }
    }
}

struct TaskRow_Previews: PreviewProvider {
    static var previews: some View {
        TaskRow(task: "Do laundry", completed: true)
    }
}
