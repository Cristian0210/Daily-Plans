//
//  PlanesApp.swift
//  Planes
//
//  Created by Cristian Vangheli on 24/2/23.
//

import SwiftUI

@main
struct PlanesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
